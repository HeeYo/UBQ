import java.io.*;
import java.net.*;
import java.util.Scanner;


public class Server{
	public static void main(String[] args) throws IOException{
		Scanner reader = new Scanner(System.in);
		ServerSocket server = null;
		Socket client = null;
		OutputStream os = null;
		DataOutputStream dos = null;
		InputStream is = null;
		DataInputStream dis = null;
				
		server = new ServerSocket(1234);
		System.out.println("Server Started  "+ InetAddress.getLocalHost() + "\nWaiting for the Client to connect");
		
		while(true){
			client = server.accept();
			System.out.println("Ŭ���̾�Ʈ�� ����Ǿ����ϴ�. IP ���� : " + client.getRemoteSocketAddress());
			os = client.getOutputStream();
			dos = new DataOutputStream(os);
			
			while(true){
				System.out.print("���� ������ �Է��ϼ��� : ");
				String result = reader.next();
				dos.writeUTF("Message From Server : " + result);
			
			if(dis.readUTF() == "quit") break;
			}
			
			
			
			os.close();
			dos.close();
			client.close();
		}
	}
}