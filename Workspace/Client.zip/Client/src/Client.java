import java.io.*;
import java.net.*;

public class Client {
	public static void main(String[] args) throws IOException{
		Socket client = new Socket("127.0.0.1", 1234);
		InputStream is = client.getInputStream();
		DataInputStream dis = new DataInputStream(is);
		String receive = new String(dis.readUTF());
		
		System.out.println(receive);
		is.close();
		dis.close();
		client.close();
	}

}
